Распаковать в любую папку оба файла.
Запустить iCCupUnrealLobbyManager.exe от имени администратора.

Требуется NET FRAMEWORK 4.8 (Windows7+)